<?php
session_start();

// Tanginamo logged in ka na
if (isset($_SESSION['user_id'])) {
    header("Location: ../Index/home-page.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/Signup.css" />
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet" />
    <script src="../js/index.js"></script>
    <title>Signup</title>
</head>
<body>
    <!-- BRAIN IMAGE -->
    <div class="ImageBrain">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223456028557971506/420604729_213168628542802_4470638483137363041_n.png?ex=6619eb37&is=66077637&hm=4ef49b3c341efb9b9257513de7dac0e3a0a80a95d24bde7d13b1096647099c1d&=&format=webp&quality=lossless&width=749&height=468" alt="Brain" />
    </div>
    <!-- HEADER -->
    <div class="header">
        <!-- LOGO -->
        <div class="logo">
            <img src="https://scontent.fmnl17-2.fna.fbcdn.net/v/t1.15752-9/416254564_229762756884500_5050083700608708339_n.png?_nc_cat=111&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEMt8jjZTEtn_GreL2TVYG8S7TkXl5c5JZLtOReXlzklhk0dDkNwv--04WqKhenVzWebcEiajVdeM3ne_fAydVy&_nc_ohc=xzyIF9bMFIsAX8glpad&_nc_ht=scontent.fmnl17-2.fna&oh=03_AdRnOnQCI-m0LKBRI9H5qa-7faUDG4tmAqMRE2Hh4GUBDQ&oe=6618879E" alt="Logo" />
           <div class="heading-2"> <h2>EduQuiz</h2></div> 
        </div>

     
    </div>
    <div class="containerForm">
        <div class="heading-content">
            <div class="heading-1"> <h1>Create an Account</h1></div>  
            <div class="heading-2"> <h3>Already have an account? <a href="../login/login.php">Login</a></h3></div> 
        </div>
        <form action="signup_process.php" method="post" id="form">
            <div class="fullname">
                <span class="firstname">
                    <!-- FIRST NAME -->
                    <label for="firstname">First Name</label>
                    <input type="text" id="firstname" name="firstname" required />
                </span>
                <!-- LAST NAME -->
                <span class="lastname">
                    <label for="lastname">Last Name</label>
                    <input type="text" id="lastname" name="lastname" required />
                </span>
            </div>
            <!-- EMAIL -->
            <div class="email_address">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" required />
            </div>

            <!-- PASSWORD -->
            <div class="Password">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required />
            </div>

            <!-- REPEAT-PASSWORD -->
            <div class="RepeatPassword">
                <label for="RepeatPassword">Repeat Password</label>
                <input type="password" id="repeatpassword" name="repeatpassword" required />
            </div>
            <div class="btn-signup">
                <button type="submit" name="signup" id="submit">Sign Up</button>
            </div>
        </form>
    </div>
</body>
</html>
