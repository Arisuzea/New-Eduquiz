<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../logout/home-page.php');
    exit(); 
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
      integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="../Environment of Adobe Photoshop/style.css" />
    <title>EduQuiz Animation</title>
    <style>
      .answer-wrapper .answer:hover {
border: 2.5px solid #0c80ef;
background-color: #5BD563;
}
    </style>
  </head>
  <body>
    <div class="container-2">
    <a href="../index/quizzes.php" class="exit-btn">
      <button>Exit</button>
    </a>

      </div>
    </div>
    <!-- -Container- -->
    <div class="container">
      <div class="start-screen">
        <h1 class="heading">EduQuiz Animation</h1>
        <div class="settings">
          <label for="num-questions">Number of Questions:</label>
          <select id="num-questions">
            <option value="10">10</option>
          </select>
          <label for="category">Type of Quiz:</label>
          <select id="category">
            <option value="category">
              Environment of Adobe Photoshop Part I
            </option>
          </select>
          <label for="difficulty">Difficulty:</label>
          <select id="difficulty">
            <option value="easy">easy</option>
          </select>
          <label for="time">Time per question:</label>
          <select id="time">
            <option value="15">15 seconds</option>
          </select>
        </div>
        <button class="btn start">Start Quiz</button>
      </div>     
      <div class="quiz hide">
        <div class="timer">
          <div class="progress">
            <div class="progress-bar"></div>
            <span class="progress-text"></span>
          </div>
        </div>
        <div class="question-wrapper">
          <div class="number">
            Question <span class="current">1</span>
            <span class="total">/10</span>
          </div>
          <div class="question">This is a question This is a question?</div>
        </div>
        <div class="answer-wrapper">
          <div class="answer selected">
            <span class="text">answer</span>
            <span class="checkbox">
              <i class="fas fa-check"></i>
            </span>
          </div>
        </div>
        <button class="btn next">Next</button>
      </div>

      <div class="end-screen hide">
        <h1 class="heading">EduQuiz Animation</h1>
        <div class="score">
          <span class="score-text">Your score:</span>
          <div>
            <span class="final-score">0</span>
            <span class="total-score">/10</span>
          </div>
        </div>
        <div class="button-gap">
          <button class="btn restart">Restart Quiz</button>
      </div>
    </div>
   </div>
   <!-- ------ -->
   <div class="remark">
    <p id="explanation-p" class="explanation" style="display: none;">
  </div>
    <script>
      function myFunction() {
        var x = document.getElementById("explanation-p");
        if (x.style.display === "none") {
          x.style.display = "block";
        } else {
          x.style.display = "none";
        }
      }

    </script>

    <script src="script.js"></script>
  </body>
</html>
