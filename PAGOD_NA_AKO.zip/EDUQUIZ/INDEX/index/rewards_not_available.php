<?php
session_start();
include '../connect.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rewards Not Available</title>
</head>
<body>
    <h1>Rewards Not Available Yet</h1>
    <p>Sorry, you have already received a reward in the last 24 hours. Please try again later.</p>
</body>
</html>
