<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the home page
    header('Location: ../logout/home-page.php');
    exit(); // Stop further execution
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="../css/home-page.css" />
    <link rel="stylesheet" type="text/css" href="../css/login/home-page.css" />
    <link rel="stylesheet" type="text/css" href="../css/template/scrollbar.css" />
    <link rel="stylesheet" type="text/css" href="../css/template/scrollup.css" />

    <link rel="shortcut icon" href="https://scontent.fmnl17-2.fna.fbcdn.net/v/t1.15752-9/416254564_229762756884500_5050083700608708339_n.png?_nc_cat=111&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeEMt8jjZTEtn_GreL2TVYG8S7TkXl5c5JZLtOReXlzklhk0dDkNwv--04WqKhenVzWebcEiajVdeM3ne_fAydVy&_nc_ohc=iRyVOQvgDXAAX8b7Hwp&_nc_ht=scontent.fmnl17-2.fna&oh=03_AdSe7B8d5Ia9g3NJSZBi1B2VW__Dghbi7LYl4iHnyu6-sA&oe=6603A7DE" type="image/x-icon">
    <script src="../js/index.js"></script>
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <title>Homepage</title>
  </head>
<!-- ---------HEADER---------- -->
    <div class="header">
      <!-- NAVIGATION BAR -->
      
      <div class="topnav" id="topnav">
        <!-- <img onclick="Settings()" src="https://media.discordapp.net/attachments/1223234109283762271/1224680176718446733/PS.png?ex=661e5f4b&is=660bea4b&hm=611066f6aaa67b59175b7b9ef179bd17723cb31324c293d3ad4b169f80b14862&=&format=webp&quality=lossless&width=468&height=468" alt="Expired" >  -->
            <a id="person_circle" href="settings_personal-info.php"><ion-icon name="person-circle"></ion-icon></a> 
            <a class="active" href="#form">Contact Us</a>
            <a href="#about">About</a>
            <a href="quizzes.php">Quizzes</a>

      </div>
    </div>
    <div class="logo"><img src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344" alt="">
      <h3>EduQuiz</h3>
    </div>
<!-- ------------------- -->

<!-- CONTENT -->
    <div class="content-1"> 
        <!-- DITO MALALAGAY YUNG USERNAME PAG NAG SIGN UP SI USER  --> <!-- Hello <php?>Guest</php?>-->
         <!-- TEMPORARY NOT AVAILABLE (BACKEND DEV CAN ONLY CHANGE THIS....-CJ) -->
      <div class="intro">
         <p>Hello, guest!</p>
            <h1>Let's put ourselves to a challenge and get learning!</h1>
      </div>
      <!-- SEARCH TOPIC -->
      <div class="search-bar">
        <input type="text"class="icon" id="search" placeholder="Search any topic you like" >
      </div>
    </div>
<!-- --------------- -->
    <div class="parent-adobe">
                    <!-- -------- Environment of Adobe Photoshop-------------->
      <div class="child-adobe">
      <div class="adobe-img">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1224368712304431284/PS_2.png?ex=661d3d38&is=660ac838&hm=2cde55377023cd2931ae18e28138bf926b6497337fc3a21308a13fc2384ea99c&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
        <div class="adobe-text">
           <span class="span_p-1"><p>15 items</p></span>
           <span class="span_h2-1"><h2>Environment of Adobe Photoshop</h2></span>
           <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
        <span class="span_btn-1"><a href="../../Environment of Adobe Photoshop/index.html"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></a></span>   
        </div>
      </div>
    </div>
                                    <!---------------------- -->
                  <!-- ------------ History of Adobe Photoshop---------------->
    <div class="child-adobe"> 
      <div class="adobe-img">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1224387182442315787/PS_3.png?ex=661d4e6c&is=660ad96c&hm=49c4402912a599d051a1abe83de3a8a0dae9c6ad37083229dcdf9753347e6788&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
        <div class="adobe-text">
           <span class="span_p-1"><p>15 items</p></span>
           <span class="span_h2-1"><h2>History of Adobe Photoshop<h2></span>
           <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
           <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
      </div>
    </div>
                                  <!------------------------>
               <!-- ------------ Different Tools in Adobe Photoshop---------------->
                   
    <div class="child-adobe">
      <div class="adobe-img">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1224389386100150362/PS_5.png?ex=661d5079&is=660adb79&hm=fdf213c17e4134016eada1cb0bb329823f3935ec14ca223eb9d4b6f426f0f88c&=&format=webp&quality=lossless&width=350&height=350" alt="Adobepic">
        <div class="adobe-text">
           <span class="span_p-1"><p>15 items</p></span>
           <span class="span_h2-1"><h2>Different Tools in Adobe Photoshop</h2></span>
           <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
           <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
      </div>
    </div>
    <div class="btn-morequiz">
      <button>More Quiz</button>
    </div>
    <!-- -------contact us----------- -->
    <div class="contactus-form" id="form">
 
    <div class="contactus-h1">
      <h1>Let me know what's on your mind</h1>
    </div>
      <form method="POST" action="contact_form_handler.php">
        <div class="label-fullname">
          <label for="firstname" id="label_firstname">Firstname</label>
          <label for="lastname" id="label_lastname">Lastname</label>
        </div>
        <!-- FULLNAME -->
        <div class="input-fullname">
          <input type="text" id="firstname" name="firstname" placeholder="First Name" required />
          <input type="text" id="lastname" name="lastname" placeholder="Last Name" required />
        </div>
      <!-- EMAIL ADDRESS -->
        <div class="email_address">
            <div class="label-email_address"><label for="label-email_address">Email Address</label></div>
          <input type="email" id="email" name="email" placeholder="Email Address" required>
        </div>
        <!-- LEAVE US A MESSAGE -->
        <div class="message">
          <div class="label-message">
            <label for="message">Leave us a message...</label>
          </div>
          <textarea name="message" id="message" cols="30" rows="10" required></textarea>    
        </div>
        <!-- SUBMIT BUTTON -->
        <div class="btn-submit">
          <button>Submit</button>
        </div>
      </form>
          <!-- FOOTER -->
        <span class="footer">
          <footer> <a href="#topnav">© 2024 by EduQuiz. Powered and secured by ___</a></footer>
          <span class="scroll-up"><a href="#topnav"><ion-icon name="chevron-up"></ion-icon></a></span>
        </span>
  
    </div>

    <!-- FOOTER -->
  
    

    <!-- -------------------- -->
    </div> <!-- PARENT-1 DIV -->
  <div class="parent-adobe-2"> <!-- PARENT-2  -->
    <div class="child-adobe-2">
    <div class="child-adobe-text_2">
      <h1>Learn about Adobe Photoshop with EduQuiz</h1>
    </div>
    <div class="child-adobe-img_2">
      <img src="https://media.discordapp.net/attachments/1223234109283762271/1224392906719236207/PS_6.png?ex=661d53c1&is=660adec1&hm=90dd0982ebf10329ca98de4b7840b1817203b93bc1c9f0e3d6ae2e98e824041c&=&format=webp&quality=lossless&width=350&height=350" alt="Intro Adobephoto Pic">
    </div>
    <div class="child-adobe-lorem">
      <p>EduQuiz helps you test your designing skills, specifically with Adobe Photoshop. It's all about seeing how well you can create designs using this software. You'll find quizzes and challenges that let you practice different techniques, from basic to advanced, all within Adobe Photoshop. Whether you're just starting out or you're already experienced, EduQuiz is a great way to learn and improve your designing skills with Adobe Photoshop.</p>
    </div>
  </div>
  <!-- ABOUT -->
  <div class="child-adobe-3">
    <div class="child-adobe-text_3" id="about"><h1>About</h1></div>
    lorem10000
  </div>
  </div>
 
  </body>
</html>


