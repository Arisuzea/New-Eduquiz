<?php
// Connect to your database (replace placeholders with actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eqs";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Query your database to fetch quiz questions from the 'quiz_questions' table
$sql = "SELECT id, question, correct_answer, incorrect_answers, explanation FROM quiz_questions";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $questions = array();

  while ($row = $result->fetch_assoc()) {
    $question = array(
      "id" => $row["id"],
      "question" => $row["question"],
      "correct_answer" => $row["correct_answer"],
      "incorrect_answers" => json_decode($row["incorrect_answers"]),
      "explanation" => $row["explanation"]
    );
    array_push($questions, $question);
  }

  // Return the questions as JSON
  echo json_encode(array("questions" => $questions));
} else {
  echo "No questions found";
}

$conn->close();
?>
