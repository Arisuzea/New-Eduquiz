<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About Us</title>
    <link
      rel="stylesheet"
      type="text/css"
      href="../css/template/scrollbar.css"
    />
    <link rel="stylesheet" type="text/css" href="../css/template/header.css" />
    <link rel="stylesheet" type="text/css" href="../css/about.css" />
    <link rel="stylesheet" type="text/css" href="../css/template/scrollup.css" />
    <link rel="shortcut icon" href="#" type="image/x-icon" />
    <script src="../js/index.js"></script>
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <style>
      .fourth-child-span-h3 h3 {
  margin-top: -0.5rem;
  font-size: 20px;
  font-weight: lighter;
  margin-left: 20px;
}
#padora {
  position: relative;
  top: 5.5555555555%;
}
.fourth-child-span-h2 h2 {
  margin-top: 10px;
  font-size: 25px;
  font-weight: lighter;
  margin-left: 20px;
}
.fourth-child-span-p p {
  margin-top: 20px;
  width: 356px;
  font-size: 25.1px;
  font-weight: lighter;
  display: flex;
  text-align: justify;
  align-items: center;
  margin-left: 20px;
}
.fourth-child-span-p {
  display: flex;
  justify-content: space-between;
}

    </style>
  </head>
  <body>
  <script>
        function Settings() {
  window.location = "../index/settings_personal-info.php";
}
      </script>
    <!-- ---------HEADER---------- -->
    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav" id="topnav">
        <img
          onclick="Settings()"
          src="https://media.discordapp.net/attachments/1223234109283762271/1224680176718446733/PS.png?ex=661e5f4b&is=660bea4b&hm=611066f6aaa67b59175b7b9ef179bd17723cb31324c293d3ad4b169f80b14862&=&format=webp&quality=lossless&width=468&height=468"
          alt="Expired"
        />
        <a class="active" href="../index/home-page.php">Contact Us</a>
        <a href="#">About</a>
        <a href="quizzes.php">Quizzes</a>
        <a href="../index/home-page.php">Home</a>
      </div>
      <div class="logo">
        <img
          src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344"
          alt="Expired"
        />
        <h3>EduQuiz</h3>
      </div>
    </div>

    <!-- ------------------- -->
    <div class="container" id="container">
      <!-- FIRST CHILD -->
      <div class="first-child">
        <h1>About Us</h1>
        <span class="lower-child-p">
          <p>
            Find out additional information about the website and its creators.
          </p></span
        >
      </div>
      <!-- SECOND CHILD  -->
      <!-- CARD -->

      <div class="second-child">
        <h1>What we offer</h1>
        <div class="position-card">
          <div class="card">
            <span class="ion-icon_document"
              > <a href="../index/quizzes.php"><img
                src="https://media.discordapp.net/attachments/1223234109283762271/1226106124118265946/list.png?ex=66238f4f&is=66111a4f&hm=470042b34a9b5f7a353c4c56046593aa51922ba58210926cc7bddb27805949dd&=&format=webp&quality=lossless&width=468&height=468"
                alt="Expired"
            /></a></span>
            <h2>Interesting quizzes</h2>
            <p>
              You can take numerous types of quizzes relating to Adobe Photoshop
              on EduQuiz.
            </p>
          </div>
          <div class="card">
            <span class="ion-icon_document"
              ><img
                src="https://media.discordapp.net/attachments/1223234109283762271/1226106471528402944/smart-energy.png?ex=66238fa2&is=66111aa2&hm=ad145cc45303366e2c1cfb3514e97c9ebd6b3a3d01a74d0b64e5e0f57e327463&=&format=webp&quality=lossless&width=468&height=468"
                alt="Expired"
            /></span>
            <h2>Insightful Information</h2>
            <p>
              Each quiz in EduQuiz will also provide you with useful information
              about using Adobe Photoshop.
            </p>
          </div>
          <div class="card">
            <span class="ion-icon_document"
              ><a href="../index/home-page.php"><img
                src="https://media.discordapp.net/attachments/1223234109283762271/1226104925092577300/contact-mail.png?ex=66238e32&is=66111932&hm=dd8907ecabbc0ea219a34746aada4c3c04c1c468e8f5e767e2dea9a0747c2a77&=&format=webp&quality=lossless&width=468&height=468"
                alt="Expired"
            /></a></span>
            <h2>Contact Us</h2>
            <p>
              We are also willing to accept your feedback to better understand
              what we needs to improve on our website.
            </p>
          </div>
        </div>
      </div>
      <!-- THIRD CHILD -->
      <div class="third-child">
        <div class="third-child-content">
          <h1>
            Our goal is to see if online quizzes have an impact on how you
            learn.
          </h1>
          <span class="content-p-1">
            <p>
              EduQuiz was developed to investigate the effectiveness of online
              quizzes in enhancing students' learning experiences. Specifically,
              the platform focused on Adobe Photoshop, aiming to assess
              students' understanding and retention of graphic design concepts.
              Each quiz was meticulously crafted to cover various aspects of
              Photoshop, from basic tools to advanced features, with the goal of
              evaluating both comprehension and practical application.
            </p>
          </span>
          <span class="content-p-2">
            <p>
              EduQuiz was developed to investigate the effectiveness of online
              quizzes in enhancing students' learning experiences. Specifically,
              the platform focused on Adobe Photoshop, aiming to assess
              students' understanding and retention of graphic design concepts.
              Each quiz was meticulously crafted to cover various aspects of
              Photoshop, from basic tools to advanced features, with the goal of
              evaluating both comprehension and practical application.
            </p>
          </span>
        </div>
        <div class="third-child-img">
          <img
            src="https://media.discordapp.net/attachments/1223234109283762271/1226163935263068241/PS_9.png?ex=6623c527&is=66115027&hm=7b54d78fee401e78e26e20737cfc903132cfd42bd259510cff2d66103f18b772&=&format=webp&quality=lossless&width=683&height=683"
            alt="Expired"
          />
        </div>
      </div>
      <!-- fourth-child -->
      <div class="fourth-child">
        <h1>Meet the Team</h1>
        <!-- cj -->
        <div class="fourth-child-content">
          <div class="fourth-child-card">
            <div class="fourth-child-img"> <img src="https://media.discordapp.net/attachments/1223234109283762271/1226203926391423006/PS_14.png?ex=6623ea65&is=66117565&hm=40b51997538e2839f399233aee61450a037fccb0d6abeb9d13bf03853e271d4b&=&format=webp&quality=lossless&width=683&height=683" alt="Expired"></div>
           <span class="fourth-child-span-h3"><h3>Web Front-end Developer</h3></span> 
           <span class="fourth-child-span-h2"> <h2>Carl John C. Sto Tomas</h2></span>
            <span class="fourth-child-span-p"><p>As a creative front-end developer, I'm passionate about creating digital experiences that are both visually appealing and easy to use for users.</p></span>
            <span class="fourth-child-span-p"><p><ion-icon name="mail"></ion-icon>carljohnstotomas18@gmail.com</p></span>

          </div>
        
        <!--wilfren -->
     
          <div class="fourth-child-card">
            <div class="fourth-child-img"> <img src="https://media.discordapp.net/attachments/1223234109283762271/1226218420479987804/PS_15.png?ex=6623f7e5&is=661182e5&hm=cf0420a5dae7c837cd90b214b59128a948b12b6b7d6efa088b6628574cc02434&=&format=webp&quality=lossless" alt="Expired"></div>
           <span class="fourth-child-span-h3"><h3>Web Designer</h3></span> 
           <span class="fourth-child-span-h2"> <h2>Wilfren T. Padora Jr.</h2></span>
            <span class="fourth-child-span-p"><p>As a novice in web design, I enjoyed honing my creative abilities and gaining wonderful experiences.</p></span>
            <span class="fourth-child-span-p" id="padora"><p><ion-icon name="mail"></ion-icon>wilfrenpadora06@gmail.com</p></span>
          </div>
        <!-- conde -->
             
        <div class="fourth-child-card">
          <div class="fourth-child-img"> <img src="https://media.discordapp.net/attachments/1223234109283762271/1226218946508619848/PS_16.png?ex=6623f862&is=66118362&hm=ffb475f30b6e77c2e37bd5c1f9298177cc15d708f61365ae3d7297b9f78b7da2&=&format=webp&quality=lossless" alt="Expired"></div>
         <span class="fourth-child-span-h3"><h3>Web Back-end Developer</h3></span> 
         <span class="fourth-child-span-h2"> <h2>Reister Gerald G. Conde</h2></span>
          <span class="fourth-child-span-p"><p>I’m a back-end developer studying at Arellano University ICT Strand, proficient in PHP, JavaScript, Python, and SQL.</p></span>
          <span class="fourth-child-span-p"><p><ion-icon name="mail"></ion-icon>geraldconde201@gmail.com</p></span>

        </div>
        
      </div>
          <!-- FOOTER -->
          <span class="footer">
            <footer> <a href="#topnav">© 2024 by EduQuiz. Powered and secured by ___</a></footer>
            <span class="scroll-up"><a href="#topnav" style="left: 147%; position: absolute; top: 123.5%;"><ion-icon name="chevron-up"></ion-icon></a></span>
          </span>
      </div>
    
    </div>
  </body>
</html>
