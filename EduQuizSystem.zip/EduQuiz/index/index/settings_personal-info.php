<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the home page
    header('Location: ../logout/home-page.php');
    exit(); // Stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/settings_personal-info.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script src="../js/index.js"></script>
    <title>Settings</title>
    <style>

    </style>
</head>
<body>

<!-- ---------HEADER---------- -->
<div class="header">
    <!-- NAVIGATION BAR -->
    <div class="topnav" id="topnav">
        <img onclick="Settings()" src="https://media.discordapp.net/attachments/1223234109283762271/1224680176718446733/PS.png?ex=661e5f4b&is=660bea4b&hm=611066f6aaa67b59175b7b9ef179bd17723cb31324c293d3ad4b169f80b14862&=&format=webp&quality=lossless&width=468&height=468" alt="Expired">        
        <a class="active" href="../index/home-page.php" onclick="MyfunctionLogin()">Contact Us</a>
        <a href=".../index/home-page.php">About</a>
        <a href="../index/quizzes.php">Quizzes</a>
    </div>
</div>
<script>
          function Settings() {
          window.location = "../index/settings_personal-info.php";}
      </script>
<div class="logo">
    <a href="home-page.php"><img src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344" alt="Logo"></a>
    <h3>EduQuiz</h3>
</div>

<!-- ------------------- -->

<!--  -->
<div class="hero">
    <div class="container_1">
        <h1>Settings</h1>
        <a href="../index/settings_personal-info.php" id="id_1">Personal Info</a>
        <a href="../index/settings_login-security.php" id="id_2">Login & Security</a>
        <!-- HR > Horizontal Rule (Line)  -->
        <span class="hr_1"> <hr></span>
        <span class="hr-faq">
            <hr>
        </span>
    </div>

    <div class="container_2">
    <p>Profile Photo:</p>
    <img id="profile-photo" src="https://media.discordapp.net/attachments/1223234109283762271/1223498561547927626/423541781_1597380424450860_699125552750773037_n.png?ex=661a12d4&is=66079dd4&hm=0090d82b32d3d120bc7197f928a4ceea2874a743675e8183fb740f138d2d26c0&=&format=webp&quality=lossless&width=749&height=468">
    <span class="btn_rmv_chng">
        <button class="rmv_pht" id="rmv_pht" onclick="removePhoto()">Remove photo</button>
        <input type="file" id="upload-photo" style="display: none;" accept="image/*">
        <button class="chng_pht" id="chng_pht" onclick="document.getElementById('upload-photo').click()">Change photo</button>
    </span>
    <!-- HR > Horizontal Rule (Line)  -->
    <span class="hr_2">
        <hr>
    </span>
</div>

    <div class="container_3" style="positive:relative; left:10%;">
    <div class="edit_name">
        <form action="update_profile.php" method="POST">
            <label for="new-firstname">First Name:</label>
            <input type="text" name="new-firstname" id="new-firstname" required>
            <label for="new-lastname">Last Name:</label>
            <input type="text" name="new-lastname" id="new-lastname" required>
            <button type="submit" class="btn-change-name" id="id-name">Save</button>
        </form>
    </div>
</div>
</body>
</html>