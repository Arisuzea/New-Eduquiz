<?php
session_start();

// Check if user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Mag login ka gago
    header("Location: ../Login/login.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="/Eduquiz/css/faq.css" />
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <title>FAQ</title>
  </head>
  <div>
    
    <!-- TOGGLE SIDE BAR (HAMBUGER MENU) -->
    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav">
        <a class="active" href="/Eduquiz/HTML/Index/faq.php">FAQ</a>
        <a href="/Eduquiz/HTML/Index/ContactUs.php">Contact Us</a>
        <a href="/Eduquiz/HTML/Index/about.php">About</a>
      </div>
      <!-- LOGO -->
      <!-- If kung nagkaroon ng error sa link ng img>= Homepage.html. Paki re-link na lang -->
      <div class="logo">
        <a href="/eduquiz/html/Index/home-page.php"
          ><img src="https://scontent.fmnl17-2.fna.fbcdn.net/v/t1.15752-9/416254564_229762756884500_5050083700608708339_n.png?_nc_cat=111&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeEMt8jjZTEtn_GreL2TVYG8S7TkXl5c5JZLtOReXlzklhk0dDkNwv--04WqKhenVzWebcEiajVdeM3ne_fAydVy&_nc_ohc=iRyVOQvgDXAAX8b7Hwp&_nc_ht=scontent.fmnl17-2.fna&oh=03_AdSe7B8d5Ia9g3NJSZBi1B2VW__Dghbi7LYl4iHnyu6-sA&oe=6603A7DE" alt=""
        /></a>
        <h3>EduQuiz</h3>
      </div>
    </div>

    <!-- TOGGLE ICON  -->
    <input type="checkbox" class="togggle-sidebar" id="togggle-sidebar" />
    <label for="togggle-sidebar" class="toggle-icon">
      <div class="bar-top"></div>
      <div class="bar-center"></div>
      <div class="bar-bottom"></div>
    </label>
    <div class="content-1">
   
      <img src="https://scontent.fmnl17-2.fna.fbcdn.net/v/t1.15752-9/423454378_941513603665260_2158851147912735940_n.png?_nc_cat=109&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeGIuN3PZ29ZpDZDQyM-xnS1L76WbrtBq8EvvpZuu0GrwckYXd3uOOd0NtLxUdfXJf61QynqstS4yAeAZJ9xQc48&_nc_ohc=jaGKkH76iJ8AX8KZNU0&_nc_ht=scontent.fmnl17-2.fna&oh=03_AdSCSkiejOQUU4xxvTQj80i9e94JVsEb-jdz9O1_CQwvCg&oe=660650CB" alt="UTAK MAN">
      
       <div class="content-2">
        <h1>Have questions?</h1>
         <h2>We’ve got your back!</h2>
         <p>Below you’ll find answers to the most common questions that we received regarding EduQuiz. Also, feel free to check out our contact information if you still can’t find the answers you’re looking for, just <a href="/HTML/ContactUs.html">Contact Us</a>.</p>
     </div>
     <!-- FAQ ACCORDION -->
          
     <div class="container-3">
      <h1> FREQUENTLY ASKED QUESTIONS </h1>
        <!-- <h2></h2> -->
      <div class="accordion">
        <div class="accordion-item">
          <button id="accordion-button-1" aria-expanded="false"><span class="accordion-title">1</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-2" aria-expanded="false"><span class="accordion-title">1</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-3" aria-expanded="false"><span class="accordion-title">1</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-4" aria-expanded="false"><span class="accordion-title">1</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-5" aria-expanded="false"><span class="accordion-title">1</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
      </div>
    </div>
    <!-- FAQ 2 -->
    <div class="container-4">
      <!-- <h2>Frequently Asked Questions</h2> -->
      <div class="accordion">
        <div class="accordion-item">
          <button id="accordion-button-1" aria-expanded="false"><span class="accordion-title">2</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-2" aria-expanded="false"><span class="accordion-title">2</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-3" aria-expanded="false"><span class="accordion-title">2</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-4" aria-expanded="false"><span class="accordion-title">2</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
        <div class="accordion-item">
          <button id="accordion-button-5" aria-expanded="false"><span class="accordion-title">2</span><span class="icon" aria-hidden="true"></span></button>
          <div class="accordion-content">
            <p>#</p>
          </div>
        </div>
      </div>
    </div>
     <!--  -->
     <!-- JS FAQ -->
     <script>const items = document.querySelectorAll(".accordion button");

      function toggleAccordion() {
        const itemToggle = this.getAttribute('aria-expanded');
        
        for (i = 0; i < items.length; i++) {
          items[i].setAttribute('aria-expanded', 'false');
        }
        
        if (itemToggle == 'false') {
          this.setAttribute('aria-expanded', 'true');
        }
      }
      
      items.forEach(item => item.addEventListener('click', toggleAccordion));</script>
    </div>




<div class="sidebar">
    <div class="profile">
      <img src="https://scontent.fmnl17-4.fna.fbcdn.net/v/t1.15752-9/423541781_1597380424450860_699125552750773037_n.png?_nc_cat=105&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeENF9Po7kYAFTPZhGT2d-9iSwqhBsvgafBLCqEGy-Bp8Oq8rFPydDTk8zFCYoCqF_zVefFcIEOoTpP4v19fRHp4&_nc_ohc=CR8NGDfaAQ0AX9KLBSJ&_nc_oc=AQntsm06ZmvIY9djyS9lvYRAMg4MUmOdMn0MZUbmg0WJ4SIQqQsDScVbKtqXni28QgY&_nc_ht=scontent.fmnl17-4.fna&oh=03_AdQkJnhVgAZaUsRaUL5nSKoy7jRZsnwqKYgtTRupCsnbzw&oe=660384A7" alt="UI FILLED PROFILE" />
     
 
    </div>
    <ul class="menu">
      <li>
        <a href="/Eduquiz/HTML/Index/home-page.php"><ion-icon name="home-outline"></ion-icon>Home</a>
      </li>
      <li>
        <a href="/Eduquiz/HTML/Index/create.php"><ion-icon name="create-outline"></ion-icon>Create</a>
      </li>
      <li>
        <a href="#"><ion-icon name="library-outline"></ion-icon>Library</a>
      </li>
      <li>
        <a href="/Eduquiz/HTML/Index/settings_personal-info.php"><ion-icon name="settings-outline"></ion-icon>Settings</a>
      </li>
    </ul>
    
  </div>

    <!-- HR > Horizontal Rule (Line)  -->
    <hr>
    <div class="hr-faq">
    <hr>
 </div>
 
</div>
</body>
</html>
