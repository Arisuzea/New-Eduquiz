<?php
// Connect to your database (replace placeholders with actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eqs";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get a list of all tables in the database
$tablesQuery = "SHOW TABLES";
$tablesResult = $conn->query($tablesQuery);

if ($tablesResult->num_rows > 0) {
    $tables = array();

    while ($tableRow = $tablesResult->fetch_assoc()) {
        $tableName = $tableRow['Tables_in_eqs'];

        // Query each table for a random question
        $randomQuestionQuery = "SELECT id, question, correct_answer, incorrect_answers, explanation FROM $tableName ORDER BY RAND() LIMIT 1";
        $randomQuestionResult = $conn->query($randomQuestionQuery);

        if ($randomQuestionResult->num_rows > 0) {
            $row = $randomQuestionResult->fetch_assoc();
            $question = array(
                "id" => $row["id"],
                "question" => $row["question"],
                "correct_answer" => $row["correct_answer"],
                "incorrect_answers" => json_decode($row["incorrect_answers"]),
                "explanation" => $row["explanation"]
            );
            array_push($tables, array("table_name" => $tableName, "question" => $question));
        }
    }

    // Return the questions and their respective table names as JSON
    echo json_encode(array("questions" => $tables));
} else {
    echo "No tables found";
}

$conn->close();
?>