<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "eqs";

// Create connection
$mysqli = new mysqli($servername, $username, $password, $database);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract data from the POST request
    $id = $_POST["id"];
    $question = $_POST["question"];
    $correct_answer = $_POST["correct_answer"];
    $incorrect_answers = $_POST["incorrect_answers"];
    $explanation = $_POST["explanation"];
    $table_name = $_POST["table_name"]; // Dynamically detect table name

    // Update the question in the database
    $query = "UPDATE $table_name SET question='$question', correct_answer='$correct_answer', 
              incorrect_answers='$incorrect_answers', explanation='$explanation' WHERE id=$id";

    if ($mysqli->query($query) === TRUE) {
        echo "Question updated successfully";
    } else {
        echo "Error updating question: " . $mysqli->error;
    }
}

// Close connection
$mysqli->close();
?>
