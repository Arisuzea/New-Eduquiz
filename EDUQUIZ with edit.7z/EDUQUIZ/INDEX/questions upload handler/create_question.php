<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$database = "eqs"; 

// Create connection
$mysqli = new mysqli($servername, $username, $password, $database);
// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $table = $_POST["table_select"]; // Get the selected table name from the form
    $question = $_POST["question"];
    $correctAnswer = $_POST["correct_answer"];
    $incorrectAnswers = $_POST["incorrect_answers"];
    $explanation = $_POST["explanation"];

    // Prepare SQL statement with a variable table name
    $stmt = $mysqli->prepare("INSERT INTO $table (question, correct_answer, incorrect_answers, explanation) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $question, $correctAnswer, $incorrectAnswers, $explanation);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Question added successfully to $table.";
    } else {
        echo "Error adding question to $table: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $mysqli->close();
}
?>
