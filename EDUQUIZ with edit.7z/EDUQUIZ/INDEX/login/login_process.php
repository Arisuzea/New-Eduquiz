<?php
session_start();
include '../connect.php';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];


    // Retrieve user data from database based on email
    $stmt = $mysqli->prepare("SELECT id, email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Verify password
    if ($user && password_verify($password, $user['password'])) {
        // Goodjob
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['email'] = $user['email'];
        header("Location: ../Index/home-page.php");
        exit;
    } else {
        // Siraulo ka ba? nag register ka ba talaga?
        echo "<script>alert('Invalid email or password'); window.location.href='login.php';</script>";
        exit;
    }
}

$mysqli->close();
?>
