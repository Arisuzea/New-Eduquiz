

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="../css/home-page.css" />
    <link rel="shortcut icon" href="https://scontent.fmnl17-2.fna.fbcdn.net/v/t1.15752-9/416254564_229762756884500_5050083700608708339_n.png?_nc_cat=111&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeEMt8jjZTEtn_GreL2TVYG8S7TkXl5c5JZLtOReXlzklhk0dDkNwv--04WqKhenVzWebcEiajVdeM3ne_fAydVy&_nc_ohc=iRyVOQvgDXAAX8b7Hwp&_nc_ht=scontent.fmnl17-2.fna&oh=03_AdSe7B8d5Ia9g3NJSZBi1B2VW__Dghbi7LYl4iHnyu6-sA&oe=6603A7DE" type="image/x-icon">
    <script src="../js/index.js"></script>
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <title>Homepage</title>
    <style>
   
    </style>
  </head>

    

    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav">
      <a href="../login/login.php">Login</a>
      <a class="active" href="../logout/ContactUs.php">Contact Us</a>
        <a href="../logout/About.php">About</a>
        <a href="#" onclick="Quizzes()">Quizzes</a>
        
     <div class="logo"><img onclick="MyFunction()"style="cursor:pointer;" src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344" alt="">
        <h3>EduQuiz</h3>
      </div>
      </div>
    </div>


    <div class="content-1"> 
        <!-- DITO MALALAGAY YUNG USERNAME PAG NAG SIGN UP SI USER  --> <!-- Hello <php?>Guest</php?>-->
         <!-- TEMPORARY NOT AVAILABLE (BACKEND DEV CAN ONLY CHANGE THIS....-CJ) -->
      <div class="intro">
         <p>Hello, guest!</p>
            <h1>Let's put ourselves to a challenge and get learning!</h1>
      </div>
      <!-- SEARCH TOPIC -->
      <div class="search-bar">
        <input type="text"class="icon" id="search" placeholder="Search any topic you like" >
      
      </div>
    </div>
   
   
  


  </body>
</html>
