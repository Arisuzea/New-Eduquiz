<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="../css/About.css" />
    <script src="../js/index.js"></script>
    <title>About</title>
  </head>
  <body>
    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav">
        <a href="../login/login.php">Login</a>
        <a class="active" href="../logout/ContactUs.php">Contact Us</a>
        <a href="../logout/About.php">About</a>
        <a href="#" onclick="Quizzes()">Quizzes</a>

        <!-- HR > Horizontal Rule (Line)  -->
        <div class="hr-contact">
          <hr />
        </div>

        <div class="logo">
          <img
            onclick="Myfunction()"
            src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344"
            alt=""
          />
          <h3>EduQuiz</h3>
        </div>
      </div>
    </div>
    <!--  -->
    <!-- CONTENT-1 -->
    <!--OUR MISSION -->
    <div class="content-1">
      <div class="body-content">
        <div class="heading"><h1>Our Mission</h1></div>
        <div class="body-content-image"><img src="https://media.discordapp.net/attachments/1223234109283762271/1223467893094617149/image.png?ex=6619f644&is=66078144&hm=c337144b9d6cc480699ffafae9b02e1e436703f357ddb56fac3202b6cdd016ae&=&format=webp&quality=lossless" alt="Our Mission Image" /></div>
        <div class="body-content-p"><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Consequatur accusamus earum mollitia temporibus dolorem fugiat ipsa ad alias, atque dolorum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem vitae non, molestias eos quaerat ipsam recusandae doloremque, accusamus deserunt quod in animi optio libero quam aliquid corporis laudantium. Esse quidem ex accusantium repellendus eligendi? Doloremque et laborum modi velit. In officiis voluptatum saepe est magnam facilis illum debitis nam perferendis?</p></div>
      </div>
    </div>
  </body>
</html>
