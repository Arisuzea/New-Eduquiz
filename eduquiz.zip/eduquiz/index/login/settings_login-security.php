

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="../css/login/settings_login-security.css" />
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <title>Settings</title>
  </head>
  <div>
    
    <!-- TOGGLE SIDE BAR (HAMBUGER MENU) -->
    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav">
      <a id="person_circle" href="../login/settings_personal-info.php"><ion-icon name="person-circle"></ion-icon></a>
        <a href="../login/ContactUs.php">Contact Us</a>
        <a href="../login/about.php">About</a>
        <a href="../login/quizzes.php">Quizzes</a>
      </div>
      <!-- LOGO -->
      <!-- If kung nagkaroon ng error sa link ng img>= Homepage.html. Paki re-link na lang -->
      <div class="logo">
        <a href="../login/home-page.php"
          ><img src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=749&height=468" alt="Logo"
        /></a>
        <h3>EduQuiz</h3>
      </div>
    </div>
   
   
    <div class="hero">
    <div class="container_1">
        <h1>Settings</h1>
        <a href="../login/settings_personal-info.php" id="id_1">Personal Info</a>
        <a href="../login/settings_login-security.php"id="id_2">Login & Security</a>

           <!-- HR > Horizontal Rule (Line)  -->
        <span class="hr_1"> <hr></span>
     <span class="hr-faq">
     <hr>
  </span>
    </div>
    <!-- CHANGE EMAIL AND PASSWORD -->
    <div class="container_2">
        <div class="edit_email-password">
            <div class="edit_email">
                <label for="#">Email Address:</label>
               <input type="email" name="change-email" id="change-email" required> <button class="btn-change-name" required id="id-name"><ion-icon name="log-out-outline"></ion-icon></button>
           </div>
           <div class="edit_password">
               <label for="#">Password:</label>
              <input type="password" name="change-password" id="change-password" required> <button required class="btn-change-password" id="id-password"><ion-icon name="log-out-outline"></ion-icon></button>
           </div>
        </div>
        <div class="rmv">
            <div class="lgt"><a href="logout.php">Logout</a></div> 
         <div class="pda"><a href="">Permanent delete Account</a></div>
            </div>
      </div>
   
   

</div>
   