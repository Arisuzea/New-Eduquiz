

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="../css/home-page.css" />
    <link rel="stylesheet" type="text/css" href="../css/login/home-page.css" />
    <link rel="shortcut icon" href="https://scontent.fmnl17-2.fna.fbcdn.net/v/t1.15752-9/416254564_229762756884500_5050083700608708339_n.png?_nc_cat=111&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeEMt8jjZTEtn_GreL2TVYG8S7TkXl5c5JZLtOReXlzklhk0dDkNwv--04WqKhenVzWebcEiajVdeM3ne_fAydVy&_nc_ohc=iRyVOQvgDXAAX8b7Hwp&_nc_ht=scontent.fmnl17-2.fna&oh=03_AdSe7B8d5Ia9g3NJSZBi1B2VW__Dghbi7LYl4iHnyu6-sA&oe=6603A7DE" type="image/x-icon">
    <script src="../js/index.js"></script>
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <title>Homepage</title>
    <style>
   
    </style>
  </head>

    

    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav">
            <a id="person_circle" href="../login/settings_personal-info.php"><ion-icon name="person-circle"></ion-icon></a>
            <a class="active" href="../login/ContactUs.php">Contact Us</a>
            <a href="../login/About.php">About</a>
            <a href="../login/quizzes.php">Quizzes</a>
       <div class="logo"><img src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344" alt="">
        <h3>EduQuiz</h3>
      </div>
      </div>
    </div>


    <div class="content-1"> 
        <!-- DITO MALALAGAY YUNG USERNAME PAG NAG SIGN UP SI USER  --> <!-- Hello <php?>Guest</php?>-->
         <!-- TEMPORARY NOT AVAILABLE (BACKEND DEV CAN ONLY CHANGE THIS....-CJ) -->
      <div class="intro">
         <p>Hello, guest!</p>
            <h1>Let's put ourselves to a challenge and get learning!</h1>
      </div>
      <!-- SEARCH TOPIC -->
      <div class="search-bar">
        <input type="text"class="icon" id="search" placeholder="Search any topic you like" >
      
      </div>
    </div>
   
    <!-- <div class="content-2"> 
        <h1>Quizzes</h1>
        <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>Environment of Adobe Photoshop</h3></a>
          <p>10 items</p>
        </div>
      </div>
    </div>
  
    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223283297774211112/photoshop-history.jpg?ex=66194a59&is=6606d559&hm=c0c20065f56f3282760e2c64a36eaaf900ed2ebba86a3a47124fcc111f3bc8b8&=&format=webp&width=702&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>History of Adobe Photoshop</h3></a>
          <p>15 items</p>
        </div>
      </div>
    </div>

    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3 id="id_three">Different Tools in Adobe Photoshop</h3></a>
          <p>20 items</p>
        </div>
      </div>
    </div>
    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>History of battle of yultong</h3></a>
          <p>25 items</p>
        </div>
      </div>
    </div>
    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>Selos By Shaira HAHAHHAHAHAH</h3></a>
          <p>30 items</p>
        </div>
      </div>
    </div>
    
    </div> -->
  


  </body>
</html>
