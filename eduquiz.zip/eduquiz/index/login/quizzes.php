<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/login/quizzes.css">
    <script
    type="module"
    src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
  ></script>
    <title>Quizzes</title>

</head>
<body>

  <!-- HEADER -->
    <div class="header">
        <!-- NAVIGATION BAR -->
        <div class="topnav">
            <a id="person_circle" href="../login/settings_personal-info.php"><ion-icon name="person-circle"></ion-icon></a>
            <a class="active" href="../login/ContactUs.php">Contact Us</a>
          <a href="../login/About.php">About</a>
          <a href="../login/quizzes.php">Quizzes</a>
            <!-- HR > Horizontal Rule (Line)  -->
        <div class="hr-contact">
          <hr />
        </div>

       <div class="logo"> <img onclick="MyfunctionLogin()"style="cursor:pointer;"  src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344" alt="Logo">
          <h3>EduQuiz</h3>
        </div>
        </div>
      </div>
  <!--  -->


    <div class="content-2"> 
        <h1>Quizzes</h1>
        <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>Environment of Adobe Photoshop</h3></a>
          <p>10 items</p>
        </div>
      </div>
    </div>
  
    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223283297774211112/photoshop-history.jpg?ex=66194a59&is=6606d559&hm=c0c20065f56f3282760e2c64a36eaaf900ed2ebba86a3a47124fcc111f3bc8b8&=&format=webp&width=702&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>History of Adobe Photoshop</h3></a>
          <p>15 items</p>
        </div>
      </div>
    </div>

    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3 id="id_three">Different Tools in Adobe Photoshop</h3></a>
          <p>20 items</p>
        </div>
      </div>
    </div>
    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>History of battle of yultong</h3></a>
          <p>25 items</p>
        </div>
      </div>
    </div>
    <div class="quizzes_card">
      <div class="quizzes_content">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="">
        <div class="quizzes_content-text">
         <a href="#"> <h3>Selos By Shaira HAHAHHAHAHAH</h3></a>
          <p>30 items</p>
        </div>
      </div>
    </div>
    
    </div>
</body>
</html>

margin-left: 13px;
    position: relative;
    bottom: 3.5rem;
    left: 6rem;
    font-size: 35px;
    font-weight: lighter;