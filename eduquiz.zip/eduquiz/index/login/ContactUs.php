
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="../css/ContactUs.css" />
    <link rel="stylesheet" type="text/css" href="../css/login/ContactUs.css" />
    <script src="../js/index.js"></script>
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <title>Create</title>
  </head>
  <div>
    
    <!-- TOGGLE SIDE BAR (HAMBUGER MENU) -->
    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav">
        <a id="person_circle" href="../login/settings_personal-info.php"><ion-icon name="person-circle"></ion-icon></a>
        <a class="active" href="../login/contactUs.php">Contact Us</a>
        <a href="../login/About.php">About</a>
        <a href="../login/quizzes.php">Quizzes</a>

        <!-- HR > Horizontal Rule (Line)  -->
      <div class="hr-contact">
        <hr>
     </div>
      </div>
      <!-- LOGO -->
      <!-- If kung nagkaroon ng error sa link ng img>= Homepage.html. Paki re-link na lang -->
      <div class="logo">
      
          ><img id="id_one" onclick="MyfunctionLogin()" src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=749&height=468" alt="Logo"
        />
        <h3>EduQuiz</h3>
      </div>
    </div>

 
    <div class="content-1">
        <div class="text-form">
        <h2> Contact Us</h2>
        <p>Would you like to contact us? Please report any concerns you may have by completing the form.</p>
    </div>
    <!-- CONTACT FORM -->
    <form action="#">
      <div class="container-form">
        <div class="moving-object">
      <div class="fullname">
        <!-- FULLNAME -->
        <div class="input-group">
          <label for="firstname">First Name</label>
          <input type="text" id="firstname" name="firstname" placeholder="" required />
        </div>
        <!-- LAST NAME -->
        <div class="input-group">
          <label for="lastname">Last Name</label>
          <input type="text" id="lastname" name="lastname" placeholder="" required />
        </div>
      </div>
      <div class="input-row">
        <!--EMAIL_ADDRESS  -->
        <div class="input-group_1">
          <label for="email_address">Email Address</label>
          <input type="email" id="email_address" name="email_address" placeholder="" required />
        </div>
        <!-- EDUQUIZ_USERNAME -->
        <div class="input-group_2">
          <label for="eduquiz_username">EduQuiz Username</label>
          <input type="text" id="eduquiz_username" name="eduquiz_username" placeholder="" required />
        </div>
       <!-- MESSAGE -->
       <div class="input-group_3">
       <label for="message">What can we help you with?</label>
       <textarea name="message" id="message"  rows="5"></textarea>
    </div>
    </div>
    <div class="btn-submit">
        <button>Submit</button>
    </div>
    </div>
    </div>
    </form>
  
    </div>
<!-- CONTACT FORM -->

    
   
  </div>
  </body>
</html>
