<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION['user_id'])) {
        // $servername = "localhost:8888";
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "eqs_users";


        // Establish connection to the database
        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $form_type = $_POST['form-type'];

        // Handle email change
        if ($form_type == "email") {
            // Get new email from the form
            $new_email = $_POST['new-email'];

            // Update email in the database
            $sql = "UPDATE users SET email = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $new_email, $_SESSION['user_id']);
            $stmt->execute();
            $stmt->close();
        }

        // Handle password change
        elseif ($form_type == "password") {
            // Get new password from the form
            $new_password = $_POST['new-password'];

            // Hash the new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update password in the database
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $hashed_password, $_SESSION['user_id']);
            $stmt->execute();
            $stmt->close();
        }

        // Close the database connection
        $conn->close();

        // Redirect the user back to the settings page
        header('Location: settings_login-security.php');
        exit();
    }
}

?>
