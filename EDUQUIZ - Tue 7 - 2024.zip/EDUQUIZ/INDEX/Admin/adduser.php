<?php 

$servername = "localhost";
$username = "root"; 
$password = ""; 
$database = "eqs_users"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $database);


$firstname = "";
$lastname = "";
$email = "";
$password = "";

$errorMessage="";
$successMessage="";


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    do {
        if (empty($firstname) || empty($lastname) || empty($email) || empty($password)) {
            $errorMessage ="All the field are required";
            break;
        }
        // add new user to database
$sql = "INSERT INTO users (firstname, lastname, email, password)" . "VALUES ('$firstname','$lastname','$email','$password')";
$result = $conn->query($sql);

if (!$result) {
    $errorMessage = "Invalid query: " . $conn->error;
    break;
}


            $firstname = "";
            $lastname = "";
            $email = "";
            $password = "";
           
            $errorMessage="Add new User added correctly";

    header("location: /eduquiz/form.php");

    }while(false);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add user</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js
"></script>
</head>
<body>
    <div class="container my-5">
    <h2>Add user</h2>

    <?php 
        if (!empty($errorMessage)) {
            echo "
            <div class='alert alert-primary' role='alert'>
            
           <strong>$errorMessage</strong>
           </div> 
           <button type='button' class='btn btn-primary'>Close</button>  ";

        }
    ?> 
    </div>
    <form action="#" method="post">
        <!-- FIRSTNAME -->
    <div class="row mb-3">
        <label class="col-sm-3 col-form-label">Firstname</label>
    <div class="col-sm-6">
         <input type="text" class="form-control" name="firstname" value="<?php echo $firstname; ?>">
    </div>
    </div>
<!--LASTNAME -->
    <div class="row mb-3">
        <label class="col-sm-3 col-form-label">Lastname</label>
    <div class="col-sm-6">
         <input type="text" class="form-control" name="lastname" value="<?php echo $lastname; ?>">
    </div>
    </div>
<!--EMAIL -->
    <div class="row mb-3">
        <label class="col-sm-3 col-form-label">Email</label>
    <div class="col-sm-6">
         <input type="text" class="form-control" name="email" value="<?php echo $email; ?>">
    </div>
    </div>
  <!--PASSWORD -->

    <div class="row mb-3">
        <label class="col-sm-3 col-form-label">password</label value="<?php echo $password; ?>">
    <div class="col-sm-6">
         <input type="text" class="form-control" name="password">
    </div>
    </div>


<?php
            if (!empty($successMessage)) {
                echo "
                <div class='alert alert-primary' role='alert'>
                
               <strong>$successMessage</strong>
               </div> 
               <button type='button' class='btn btn-primary'>Close</button>  ";
    
            }
?>


<!-- BUTTON -->
<div class="row mb-3">
    <div class="offset-sm-3 col-sm-3 d-grid">
    <button type="submit" class="btn btn-primary btn-sm">Submit</button>
    </div>
</div>

<div class="row mb-3">
    <div class="offset-sm-3 col-sm-3 d-grid">
    <a href='/eduquiz/form.php' class='btn btn-primary btn-sm'>Cancel</a>
    </div>
</div>
    </form>
</body>
</html>