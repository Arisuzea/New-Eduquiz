<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the home page
    header('Location: ../logout/home-page.php');
    exit(); // Stop further execution
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/login/quizzes.css" />
    <link rel="stylesheet" href="../css/template/scrollbar.css" />

    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
    <title>Quizzes</title>
  </head>
  <body>
    <!-- HEADER -->
    <div class="header">
      <!-- NAVIGATION BAR -->

      <div class="topnav" id="topnav">
        <img
          onclick="Settings()"
          src="https://media.discordapp.net/attachments/1223234109283762271/1224680176718446733/PS.png?ex=661e5f4b&is=660bea4b&hm=611066f6aaa67b59175b7b9ef179bd17723cb31324c293d3ad4b169f80b14862&=&format=webp&quality=lossless&width=468&height=468"
          alt="Expired"
        />
      <script>
          function Settings() {
          window.location = "../index/settings_personal-info.php";}
      </script>
        <a class="active" href="../index/home-page.php">Contact Us</a>
        <a href="../index/about.php">About</a>
        <a href="../index/quizzes.php">Quizzes</a>
        <a href="../index/home-page.php">Home</a>
      </div>
    </div>
    <div class="logo">
      <a href="home-page.php">
      <img
        src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344"
        alt=""
      /></a>
      <h3>EduQuiz</h3>
    </div>
    <!--  -->
      <!-- SEARCH TOPIC -->
      <form action="#" id="search-form">
      <div class="search-bar">
        <input type="text"class="icon" name="Searchbar" id="search"  onkeyup="myFunction()" placeholder="Search any topic you like" >
      </div>
      </form>
    <div class="parent-adobe">
      <!-- javascript search-bar -->       
      <script type="text/javascript">
        function myFunction() {
          let filter = document.getElementById("search").value.toUpperCase();
          let item = document.querySelectorAll(".child-adobe");
          let l = document.getElementsByTagName("h2");
          for (var i = 0; i <= l.length; i++) {
            let a = item[i].getElementsByTagName("h2")[0];
            let value = a.innerHTML || a.innerText || a.textContent;
            if (value.toUpperCase().indexOf(filter) > -1) {
              item[i].style.display = "";
            } else {
              item[i].style.display = "none";
            }
          }
        }
      </script>
      <!-- -------- Environment of Adobe Photoshop 1-------------->
<div class="child-adobe">
<div class="adobe-img">
<img src="https://media.discordapp.net/attachments/1223234109283762271/1224368712304431284/PS_2.png?ex=661d3d38&is=660ac838&hm=2cde55377023cd2931ae18e28138bf926b6497337fc3a21308a13fc2384ea99c&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
<div class="adobe-text">
<span class="span_p-1"><p>10 items</p></span>
<span class="span_p-1"><p>15 Seconds</p></span>
<span class="span_h2-1"><h2>Environment of Adobe Photoshop Part 1</h2></span>
<span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
<span class="span_btn-1"><a href="../Environment of Adobe Photoshop/index.php"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></a></span>  
</div>
</div>
</div>
                      <!---------------------- -->
          <!-- -------- Environment of Adobe Photoshop 2-------------->
<div class="child-adobe">
  <div class="adobe-img">
  <img src="https://media.discordapp.net/attachments/1223234109283762271/1224368712304431284/PS_2.png?ex=661d3d38&is=660ac838&hm=2cde55377023cd2931ae18e28138bf926b6497337fc3a21308a13fc2384ea99c&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
  <div class="adobe-text">
  <span class="span_p-1"><p>10 items</p></span>
  <span class="span_p-1"><p>15 Seconds</p></span>
  <span class="span_h2-1"><h2>Environment of Adobe Photoshop Part 2</h2></span>
  <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
  <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span>
  </div>
  </div>
  </div>
                        <!---------------------- -->
    <!-- ------------ History of Adobe Photoshop---------------->
<div class="child-adobe"> 
<div class="adobe-img">
<img src="https://media.discordapp.net/attachments/1223234109283762271/1224387182442315787/PS_3.png?ex=661d4e6c&is=660ad96c&hm=49c4402912a599d051a1abe83de3a8a0dae9c6ad37083229dcdf9753347e6788&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
<div class="adobe-text">
<span class="span_p-1"><p>15 items</p></span>
<span class="span_p-1"><p>20 Seconds</p></span>
<span class="span_h2-1"><h2>History of Adobe Photoshop<h2></span>
<span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
<span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
</div>
</div>
                    <!------------------------>
 <!-- ------------ Different Tools in Adobe Photoshop 1---------------->
     
<div class="child-adobe">
<div class="adobe-img">
<img src="https://media.discordapp.net/attachments/1223234109283762271/1224389386100150362/PS_5.png?ex=661d5079&is=660adb79&hm=fdf213c17e4134016eada1cb0bb329823f3935ec14ca223eb9d4b6f426f0f88c&=&format=webp&quality=lossless&width=350&height=350" alt="Adobepic">
<div class="adobe-text">
<span class="span_p-1"><p>15 items</p></span>
<span class="span_p-1"><p>20 Seconds</p></span>
<span class="span_h2-1"><h2>Different Tools in Adobe Photoshop Part 1</h2></span>
<span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
<span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
</div>
</div>
                    <!------------------------>
        <!-- ------------ Different Tools in Adobe Photoshop 2---------------->
     
<div class="child-adobe">
  <div class="adobe-img">
  <img src="https://media.discordapp.net/attachments/1223234109283762271/1224389386100150362/PS_5.png?ex=661d5079&is=660adb79&hm=fdf213c17e4134016eada1cb0bb329823f3935ec14ca223eb9d4b6f426f0f88c&=&format=webp&quality=lossless&width=350&height=350" alt="Adobepic">
  <div class="adobe-text">
  <span class="span_p-1"><p>15 items</p></span>
  <span class="span_p-1"><p>25 Seconds</p></span>
  <span class="span_h2-1"><h2>Different Tools in Adobe Photoshop Part 2</h2></span>
  <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
  <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
  </div>
  </div>
                      <!------------------------>
      <!-- ------------ Digital File Format---------------->
     
      <div class="child-adobe">
        <div class="adobe-img">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
        <div class="adobe-text">
        <span class="span_p-1"><p>20 items</p></span>
        <span class="span_p-1"><p>30 Seconds</p></span>
        <span class="span_h2-1"><h2>Digital File Format</h2></span>
        <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
        <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
        </div>
        </div>
                            <!------------------------>
                     <!-- ------------ Fonts in Adobe Photoshop---------------->
  
      <div class="child-adobe">
        <div class="adobe-img">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
        <div class="adobe-text">
        <span class="span_p-1"><p>10 items</p></span>
        <span class="span_p-1"><p>15 Seconds</p></span>
        <span class="span_h2-1"><h2>Fonts in Adobe Photoshop</h2></span>
        <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
        <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
        </div>
        </div>
                            <!------------------------>
             <!-- ------------ Color Modes---------------->
  
      <div class="child-adobe">
        <div class="adobe-img">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
        <div class="adobe-text">
        <span class="span_p-1"><p>10 items</p></span>
        <span class="span_p-1"><p>15 Seconds</p></span>
        <span class="span_h2-1"><h2>Color Modes</h2></span>
        <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
        <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
        </div>
        </div>
                            <!------------------------>
              <!-- ------------ Gradient in Adobe Photoshop--------------->
  
      <div class="child-adobe">
        <div class="adobe-img">
        <img src="https://media.discordapp.net/attachments/1223234109283762271/1223246088765706330/PS_1.png?ex=661927b2&is=6606b2b2&hm=37422cfa8d447fd7e4b87c0b49393f4f828c06788357c9a1a1d9f864f93696a2&=&format=webp&quality=lossless&width=468&height=468" alt="Adobepic">
        <div class="adobe-text">
        <span class="span_p-1"><p>10 items</p></span>
        <span class="span_p-1"><p>15 Seconds</p></span>
        <span class="span_h2-1"><h2>Gradient in Adobe Photoshop</h2></span>
        <span class="span_h3-1"><h3>Challenge your understanding of Adobe Photoshop's user interface and workspace. </h3> </span>
        <span class="span_btn-1"><button>Start Now<ion-icon name="chevron-forward-outline" id="ion-1"></ion-icon></button></span> </div>
        </div>
        </div>
                            <!------------------------>
  </body>
</html>
