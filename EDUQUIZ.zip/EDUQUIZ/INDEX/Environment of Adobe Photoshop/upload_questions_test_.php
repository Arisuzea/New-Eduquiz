<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Upload, Edit, and Remove Quiz Questions</title>
<style>
 body {
    font-family: Arial, sans-serif;
    margin: 20px;
  }
  form {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
  }
  label, input, textarea, button {
    display: block;
    margin-bottom: 10px;
  }
  button {
    padding: 10px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 3px;
    cursor: pointer;
  }
  button:hover {
    background-color: #0056b3;
  }
  .question-panel {
    margin-top: 20px;
    border-top: 1px solid #ccc;
    padding-top: 20px;
  }
</style>
</head>
<body>
  <h1>Upload, Edit, and Remove Quiz Questions</h1>
  <form action="upload_questions.php" method="POST">
    <label for="question">Question:</label>
    <textarea id="question" name="question" rows="3" required></textarea>
    
    <label for="correct_answer">Correct Answer:</label>
    <input type="text" id="correct_answer" name="correct_answer" required>
    
    <label for="incorrect_answers">Incorrect Answers (comma-separated):</label>
    <input type="text" id="incorrect_answers" name="incorrect_answers" required>
    
    <label for="explanation">Explanation:</label>
    <textarea id="explanation" name="explanation" rows="3" required></textarea>
    
    <button type="submit" name="upload">Upload Question</button>
  </form>

  <div class="question-panel">
    <h2>Existing Questions</h2>
    <?php
    // Connect to your database (replace placeholders with actual database credentials)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "eqs";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve and display uploaded questions with edit and remove options
    $sql = "SELECT id, question, correct_answer, incorrect_answers, explanation FROM quiz_questions";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
        echo "<div>
                <strong>Question:</strong> " . $row["question"] . "<br>
                <strong>Correct Answer:</strong> " . $row["correct_answer"] . "<br>
                <strong>Incorrect Answers:</strong> " . $row["incorrect_answers"] . "<br>
                <strong>Explanation:</strong> " . $row["explanation"] . "<br>
                <form method='POST' action='upload_questions.php'>
                  <input type='hidden' name='question_id' value='" . $row["id"] . "'>
                  <button type='submit' name='edit'>Edit</button>
                  <button type='submit' name='remove'>Remove</button>
                </form>
              </div><hr>";
      }
    } else {
      echo "No questions found";
    }

    $conn->close();
    ?>
  </div>
</body>
</html>
