<?php
  // Connect to your database (replace placeholders with actual database credentials)
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "eqs";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Check if form is submitted for uploading a question
  if (isset($_POST["upload"])) {
    $question = $_POST["question"];
    $correct_answer = $_POST["correct_answer"];
    $incorrect_answers = $_POST["incorrect_answers"];
    $explanation = $_POST["explanation"];

    // Prepare and execute SQL query to insert data into table
    $stmt = $conn->prepare("INSERT INTO quiz_questions (question, correct_answer, incorrect_answers, explanation) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $question, $correct_answer, $incorrect_answers, $explanation);

    if ($stmt->execute()) {
      echo "Question uploaded successfully<br>";
    } else {
      echo "Error uploading question: " . $stmt->error . "<br>";
    }

    $stmt->close();
  }

  // Retrieve and display uploaded questions with edit and remove options
  $sql = "SELECT id, question, correct_answer, incorrect_answers, explanation FROM quiz_questions";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      echo "<form method='POST' action=''>
              <input type='hidden' name='question_id' value='" . $row["id"] . "'>
              <label>Question:</label>
              <textarea name='question' rows='3' required>" . $row["question"] . "</textarea>
              <label>Correct Answer:</label>
              <input type='text' name='correct_answer' value='" . $row["correct_answer"] . "' required>
              <label>Incorrect Answers (comma-separated):</label>
              <input type='text' name='incorrect_answers' value='" . $row["incorrect_answers"] . "' required>
              <label>Explanation:</label>
              <textarea name='explanation' rows='3' required>" . $row["explanation"] . "</textarea>
              <button type='submit' name='update'>Update</button>
              <button type='submit' name='remove'>Remove</button>
            </form>";
    }
  } else {
    echo "No questions found";
  }

  // Check if form is submitted for updating a question
  if (isset($_POST["update"])) {
    $question_id = $_POST["question_id"];
    $question = $_POST["question"];
    $correct_answer = $_POST["correct_answer"];
    $incorrect_answers = $_POST["incorrect_answers"];
    $explanation = $_POST["explanation"];

    // Prepare and execute SQL query to update question data
    $stmt = $conn->prepare("UPDATE quiz_questions SET question=?, correct_answer=?, incorrect_answers=?, explanation=? WHERE id=?");
    $stmt->bind_param("ssssi", $question, $correct_answer, $incorrect_answers, $explanation, $question_id);

    if ($stmt->execute()) {
      echo "Question updated successfully<br>";
    } else {
      echo "Error updating question: " . $stmt->error . "<br>";
    }

    $stmt->close();
  }

  // Check if form is submitted for removing a question
  if (isset($_POST["remove"])) {
    $question_id = $_POST["question_id"];

    // Prepare and execute SQL query to remove question from table
    $stmt = $conn->prepare("DELETE FROM quiz_questions WHERE id=?");
    $stmt->bind_param("i", $question_id);

    if ($stmt->execute()) {
      echo "Question removed successfully<br>";
    } else {
      echo "Error removing question: " . $stmt->error . "<br>";
    }

    $stmt->close();
  }

  $conn->close();
  ?>