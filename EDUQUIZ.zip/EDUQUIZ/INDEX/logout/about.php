<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About Us</title>
    <link
      rel="stylesheet"
      type="text/css"
      href="../css/template/scrollbar.css"
    />
    <link rel="stylesheet" type="text/css" href="../css/template/header.css" />
    <link rel="stylesheet" type="text/css" href="../css/about.css" />
    <link rel="shortcut icon" href="#" type="image/x-icon" />
    <script src="../js/index.js"></script>
    <script
      type="module"
      src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    ></script>
  </head>
  <body>
    <!-- ---------HEADER---------- -->
    <div class="header">
      <!-- NAVIGATION BAR -->
      <div class="topnav" id="topnav">
        <a class="active" href="../index/home-page.php">Contact Us</a>
        <a href="#">About</a>
        <a href="#" onclick="Quizzes()">Quizzes</a>
        <a href="../index/home-page.php">Home</a>
      </div>
      <div class="logo">
        <img
          src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=66191cac&is=6606a7ac&hm=f996b48bc14ba106972437901e41dbd8cdc0d9c528a675cab5d37c92a544ec1a&=&format=webp&quality=lossless&width=550&height=344"
          alt="Expired"
        />
        <h3>EduQuiz</h3>
      </div>
    </div>

    <!-- ------------------- -->
    <div class="container" id="container">
      <!-- FIRST CHILD -->
      <div class="first-child">
        <h1>About Us</h1>
        <span class="lower-child-p">
          <p>
            Find out additional information about the website and its creators.
          </p></span
        >
      </div>
      <!-- SECOND CHILD  -->
      <!-- CARD -->

      <div class="second-child">
        <h1>What we offer</h1>
        <div class="position-card">
          <div class="card">
            <span class="ion-icon_document"
              > <a href="../index/quizzes.php"><img
                src="https://media.discordapp.net/attachments/1223234109283762271/1226106124118265946/list.png?ex=66238f4f&is=66111a4f&hm=470042b34a9b5f7a353c4c56046593aa51922ba58210926cc7bddb27805949dd&=&format=webp&quality=lossless&width=468&height=468"
                alt="Expired"
            /></a></span>
            <h2>Interesting quizzes</h2>
            <p>
              You can take numerous types of quizzes relating to Adobe Photoshop
              on EduQuiz.
            </p>
          </div>
          <div class="card">
            <span class="ion-icon_document"
              ><img
                src="https://media.discordapp.net/attachments/1223234109283762271/1226106471528402944/smart-energy.png?ex=66238fa2&is=66111aa2&hm=ad145cc45303366e2c1cfb3514e97c9ebd6b3a3d01a74d0b64e5e0f57e327463&=&format=webp&quality=lossless&width=468&height=468"
                alt="Expired"
            /></span>
            <h2>Insightful Information</h2>
            <p>
              Each quiz in EduQuiz will also provide you with useful information
              about using Adobe Photoshop.
            </p>
          </div>
          <div class="card">
            <span class="ion-icon_document"
              ><a href="../index/home-page.php"><img
                src="https://media.discordapp.net/attachments/1223234109283762271/1226104925092577300/contact-mail.png?ex=66238e32&is=66111932&hm=dd8907ecabbc0ea219a34746aada4c3c04c1c468e8f5e767e2dea9a0747c2a77&=&format=webp&quality=lossless&width=468&height=468"
                alt="Expired"
            /></a></span>
            <h2>Contact Us</h2>
            <p>
              We are also willing to accept your feedback to better understand
              what we needs to improve on our website.
            </p>
          </div>
        </div>
      </div>
      <!-- THIRD CHILD -->
      <div class="third-child">
        <div class="third-child-content">
          <h1>
            Our goal is to see if online quizzes have an impact on how you
            learn.
          </h1>
          <span class="content-p-1">
            <p>
              EduQuiz was developed to investigate the effectiveness of online
              quizzes in enhancing students' learning experiences. Specifically,
              the platform focused on Adobe Photoshop, aiming to assess
              students' understanding and retention of graphic design concepts.
              Each quiz was meticulously crafted to cover various aspects of
              Photoshop, from basic tools to advanced features, with the goal of
              evaluating both comprehension and practical application.
            </p>
          </span>
          <span class="content-p-2">
            <p>
              EduQuiz was developed to investigate the effectiveness of online
              quizzes in enhancing students' learning experiences. Specifically,
              the platform focused on Adobe Photoshop, aiming to assess
              students' understanding and retention of graphic design concepts.
              Each quiz was meticulously crafted to cover various aspects of
              Photoshop, from basic tools to advanced features, with the goal of
              evaluating both comprehension and practical application.
            </p>
          </span>
        </div>
        <div class="third-child-img">
          <img
            src="https://media.discordapp.net/attachments/1223234109283762271/1226163935263068241/PS_9.png?ex=6623c527&is=66115027&hm=7b54d78fee401e78e26e20737cfc903132cfd42bd259510cff2d66103f18b772&=&format=webp&quality=lossless&width=683&height=683"
            alt="Expired"
          />
        </div>
      </div>
    </div>
  </body>
</html>
